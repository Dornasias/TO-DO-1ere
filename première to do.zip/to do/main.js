new Vue({
    el: `#tasklist`,
    data: {
        title: 'Ma Première To Do List',
        tasks: [
            { name: 'Lire un livre' },
            { name: 'faire a manger' },
            { name: 's occuper de zouzou' },
        ]
    },
    methods: {
        newItem: function () {
            if (!this.tasks.name) {
                return
            }
            this.tasks.push({
                name: this.tasks.name,
                del: ''
            });
            this.tasks.name = ````;
        },
        delItem: function (task) {
            this.tasks.splice(this.tasks.indexOf(task), 1)
        }
    }
})